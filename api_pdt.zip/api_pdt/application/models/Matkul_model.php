<?php

class Matkul_model extends CI_Model
{
    public function getMatkul($kurikulum = null)
    {
        if ($kurikulum === null) {
            return $this->db->get_where('matakuliah', ['isdel' => 0])->result_array();
        } else {
            return $this->db->get_where('matakuliah', ['kurikulum' => $kurikulum, 'isdel' => 0])->result_array();
        }
    }

    public function createMatkul($data)
    {
        $this->db->insert('matakuliah', $data);
        return $this->db->affected_rows();
    }

    public function updateMatkul($data, $matkul_id)
    {
        $this->db->update('matakuliah', $data, ['matkul_id' => $matkul_id]);
        return $this->db->affected_rows();
    }
}
