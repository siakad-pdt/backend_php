<?php

class Announcement_model extends CI_Model
{
    public function getAnnouncement($announcement_id = null)
    {
        if ($announcement_id === null) {
            return $this->db->get_where('announcement', ['isdel' => 0])->result_array();
        } else {
            return $this->db->get_where('announcement', ['announcement_id' => $announcement_id, 'isdel' => 0])->result_array();
        }
    }
}
