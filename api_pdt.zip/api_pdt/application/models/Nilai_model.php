<?php

class Nilai_model extends CI_Model
{
    public function getNilai($user_id)
    {
        $this->db->select('a.nilai_id, a.nilai, b.*');
        $this->db->from('nilai a');
        $this->db->join('matakuliah b', 'a.matkul_id = b.matkul_id');
        $this->db->where('a.user_id', $user_id);
        $query = $this->db->get()->result_array();

        return $query;
    }

}
