<?php

class Krs_model extends CI_Model
{
    public function getKrs($user_id)
    {
        $this->db->select('a.krs_id, a.user_id, b.*');
        $this->db->from('krs a');
        $this->db->join('matakuliah b', 'a.matkul_id = b.matkul_id');
        $this->db->where('a.user_id', $user_id);
        $query = $this->db->get()->result_array();

        return $query;
    }

    public function createKrs($data)
    {
        $this->db->insert('krs', $data);
        return $this->db->affected_rows();
    }

    public function updateKrs($data, $matkul_id)
    {
        $this->db->update('krs', $data, ['matkul_id' => $matkul_id]);
        return $this->db->affected_rows();
    }

    public function deleteKrsUser($user_id)
    {
        $this->db->delete('krs', ['user_id' => $user_id]);
        return $this->db->affected_rows();
    }
    public function deleteKrs($krs_id)
    {
        $this->db->delete('krs', ['krs_id' => $krs_id]);
        return $this->db->affected_rows();
    }

}
