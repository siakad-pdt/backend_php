<?php

class News_model extends CI_Model
{
    public function getNews($news_id = null)
    {
        if ($news_id === null) {
            return $this->db->get_where('news', ['isdel' => 0])->result_array();
        } else {
            return $this->db->get_where('news', ['news_id' => $news_id, 'isdel' => 0])->result_array();
        }
    }
}
