<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Announcement extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Announcement_model', 'announcement');
    }

    public function getAnnouncement_post()
    {
        $announcement_id = $this->post('announcement_id');
        if ($announcement_id === null) {
            $announcement = $this->announcement->getAnnouncement();
        } else {
            $announcement = $this->announcement->getAnnouncement($announcement_id);
        }

        if ($announcement) {
            $this->response([
                'status' => true,
                'data' => $announcement
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'data' => 'announcement not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
}
