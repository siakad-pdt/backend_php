<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Matkul extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Matkul_model', 'matakuliah');
    }

    public function getMatkul_post()
    {
        $kurikulum = $this->post('kurikulum');
        if ($kurikulum === null) {
            $matkul = $this->matakuliah->getMatkul();
        } else {
            $matkul = $this->matakuliah->getMatkul($kurikulum);
        }

        if ($matkul) {
            $this->response([
                'status' => true,
                'data' => $matkul
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'data' => 'mata kuliah not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
    public function addMatkul_post()
    {
        $data = [
            'matkul_name' => $this->post('matkul_name'),
            'sks' => $this->post('sks'),
            'code' => $this->post('code'),
            'hari' => $this->post('hari'),
            'waktu' => $this->post('waktu'),
            'hari_praktikum' => $this->post('hari_praktikum'),
            'waktu_praktikum' => $this->post('waktu_praktikum'),
            'ruang' => $this->post('ruang'),
            'sesi' => $this->post('sesi'),
            'kurikulum' => $this->post('kurikulum'),
            'createdAt' => date("Y-m-d H:i:s"),
        ];

        if ($this->matakuliah->createMatkul($data) > 0) {
            //ok
            $this->response([
                'status' => true,
                'message' => 'Mata Kuliah added successfully!'
            ], REST_Controller::HTTP_CREATED);
        } else {
            //kode not found
            $this->response([
                'status' => false,
                'message' => 'Failed to add mata kuliah!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
    public function editMatkul_post()
    {
        $matkul_id = $this->post('matkul_id');
        $data = [
            'matkul_name' => $this->post('matkul_name'),
            'sks' => $this->post('sks'),
            'code' => $this->post('code'),
            'hari' => $this->post('hari'),
            'waktu' => $this->post('waktu'),
            'hari_praktikum' => $this->post('hari_praktikum'),
            'waktu_praktikum' => $this->post('waktu_praktikum'),
            'sesi' => $this->post('sesi'),
            'ruang' => $this->post('ruang'),
            'kurikulum' => $this->post('kurikulum'),
            'updatedAt' => date("Y-m-d H:i:s"),
        ];

        if ($this->matakuliah->updateMatkul($data, $matkul_id) > 0) {
            //ok
            $this->response([
                'status' => true,
                'message' => 'Mata Kuliah updated successfully!'
            ], REST_Controller::HTTP_CREATED);
        } else {
            //kode not found
            $this->response([
                'status' => false,
                'message' => 'Failed to update mata kuliah!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function deleteMatkul_post()
    {
        $matkul_id = $this->post('matkul_id');
        $data = [
            'isdel' => 1,
            'updatedAt' => date("Y-m-d H:i:s"),
        ];

        if ($this->matakuliah->updateMatkul($data, $matkul_id) > 0) {
            //ok
            $this->response([
                'status' => true,
                'message' => 'Mata Kuliah deleted successfully!'
            ], REST_Controller::HTTP_CREATED);
        } else {
            //kode not found
            $this->response([
                'status' => false,
                'message' => 'Failed to delete mata kuliah!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
