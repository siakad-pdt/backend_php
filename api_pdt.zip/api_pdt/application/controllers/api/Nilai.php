<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Nilai extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Nilai_model', 'nilai');
    }

    public function getNilai_post()
    {
        $user_id = $this->post('user_id');
        $nilai = $this->nilai->getNilai($user_id);

        if ($nilai) {
            $this->response([
                'status' => true,
                'data' => $nilai
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'data' => 'nilai not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
}
