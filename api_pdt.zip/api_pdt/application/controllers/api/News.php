<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class News extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('News_model', 'news');
    }

    public function getNews_post()
    {
        $news_id = $this->post('news_id');
        if ($news_id === null) {
            $news = $this->news->getNews();
        } else {
            $news = $this->news->getNews($news_id);
        }

        if ($news) {
            $this->response([
                'status' => true,
                'data' => $news
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'data' => 'news not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
}
