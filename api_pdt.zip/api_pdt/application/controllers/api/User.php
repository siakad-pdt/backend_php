<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class User extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model', 'user');
    }

    public function register_post()
    {
        $password = password_hash($this->post('password'), PASSWORD_DEFAULT);
        $data = [
            'nim' => $this->post('nim'),
            'password' => $password,
            'full_name' => $this->post('full_name'),
            'jenis_kelamin' => $this->post('jenis_kelamin'),
            'nik' => $this->post('nik'),
            'agama' => $this->post('agama'),
            'tempat_tglLahir' => $this->post('tempat_tglLahir'),
            'no_hp' => $this->post('no_hp'),
            'email' => $this->post('email'),
            'tahun' => $this->post('tahun'),
            'fakultas' => $this->post('fakultas'),
            'prodi' => $this->post('prodi'),
            'dosen_pa' => $this->post('dosen_pa'),
            'createdAt' => date("Y-m-d H:i:s"),
        ];

        if ($this->user->createUser($data) > 0) {
            //ok
            $this->response([
                'status' => true,
                'message' => 'Register succesful!'
            ], REST_Controller::HTTP_CREATED);
        } else {
            //kode not found
            $this->response([
                'status' => false,
                'message' => 'failed to register!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function login_post()
    {
        $nim = $this->post('nim');
        $password = $this->post('password');
        $valid = false;
        $user = $this->user->getUser($nim);
        if(isset($user)){
            foreach($user as $a){
                if(password_verify($password, $a['password'])){
                    $valid = true;
                }
            }
        }
        
        if ($valid) {
            $this->response([
                'status' => true,
                'message' => "You've successfully logged in!",
                'data' => "You've successfully logged in!"
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => "NIM or Password don't match!",
                'data' => "NIM or Password don't match!"
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function updateProfile_post()
    {
        $password = password_hash($this->post('password'), PASSWORD_DEFAULT);
        $nim = $this->post('nim');
        $data = [
            'password' => $password,
            'full_name' => $this->post('full_name'),
            'jenis_kelamin' => $this->post('jenis_kelamin'),
            'nik' => $this->post('nik'),
            'agama' => $this->post('agama'),
            'tempat_tglLahir' => $this->post('tempat_tglLahir'),
            'no_hp' => $this->post('no_hp'),
            'email' => $this->post('email'),
            'updatedAt' => date("Y-m-d H:i:s"),
        ];

        if ($this->user->updateUser($data, $nim) > 0) {
            //ok
            $this->response([
                'status' => true,
                'message' => 'Profile updated!'
            ], REST_Controller::HTTP_CREATED);
        } else {
            //kode not found
            $this->response([
                'status' => false,
                'message' => 'failed to update profile!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
