<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Krs extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Krs_model', 'krs');
    }

    public function getKrs_post()
    {
        $user_id = $this->post('user_id');
        $krs = $this->krs->getKrs($user_id);

        if ($krs) {
            $this->response([
                'status' => true,
                'data' => $krs
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'data' => 'mata kuliah not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
    public function addKrs_post()
    {
        $matkul = json_decode($this->post('matkul_id'));

        foreach ($matkul as $a) {
            $data = [
                'matkul_id' => $a,
                'user_id' => $this->post('user_id')
            ];
            $this->krs->createKrs($data);
        }
        $this->response([
            'status' => true,
            'message' => 'Krs added successfully!'
        ], REST_Controller::HTTP_CREATED);
    }

    public function updateKrs_post()
    {
        $matkul = json_decode($this->post('matkul_id'));
        $user_id = $this->post('user_id');
        $this->krs->deleteKrsUser($user_id);
        foreach ($matkul as $a) {
            $data = [
                'matkul_id' => $a,
                'user_id' => $user_id
            ];
            $this->krs->createKrs($data);
        }
        $this->response([
            'status' => true,
            'message' => 'Krs added successfully!'
        ], REST_Controller::HTTP_CREATED);
    }
    public function deleteKrs_post()
    {

        $krs_id = $this->post('krs_id');

        if ($krs_id === null) {
            $this->response([
                'status' => false,
                'message' => 'failed to delete krs!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
            if ($this->krs->deleteKrs($krs_id) > 0) {

                $this->response([
                    'status' => true,
                    'krs_id' => $krs_id,
                    'message' => 'Krs has been deleted!'

                ], REST_Controller::HTTP_NO_CONTENT);
            } else {

                $this->response([
                    'status' => false,
                    'message' => 'Krs not found!'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }
}
